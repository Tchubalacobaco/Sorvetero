@extends('padrao')
@section('content')
<h1>Sorveteria Napolitano</h1>
@endsection