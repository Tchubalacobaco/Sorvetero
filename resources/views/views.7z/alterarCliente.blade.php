@extends('padrao')
@section('content')

<div class="container">
    <form class="row g-3" method="post" action="{{route('alterarBanco-contato',$contatos->id)}}">>
    @method('put')
    @csrf
        <div class="col-md-8">
            <label for="inputNome" class="form-label">Nome</label>
            <input type="text" class="form-control" value="{{$contatos->nomeCliente}}" name =nomeCliene id="inputNome">
        </div>

        <div class="col-md-4">
            <label for="inputFone" class="form-label">Fone</label>
            <input type="text" class="form-control" value="{{$contatos->foneCliente}}" name =foneCliente id="inputFone">
        </div>

        <div class="col-md-8">
            <label for="inputCEP" class="form-label">CEP</label>
            <input type="text" class="form-control" value="{{$contatos->cepCliente}}" name =cepCliente id="inputCEP">
        </div>

        <div class="col-md-8">
            <label for="inputCPF" class="form-label">CPF</label>
            <input type="text" class="form-control" value="{{$contatos->emailCliente}}" name =emailCliente id="inputCPF">
        </div>
    
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Alterar</button>
        </div>
    </form>
</div>

@endsection@extends('padrao')
@section('content')

<div class="container">
    <form class="row g-3" method="post" action="{{route('alterarBanco-contato',$contatos->id)}}">>
    @method('put')
    @csrf
        <div class="col-md-8">
            <label for="inputNome" class="form-label">Nome</label>
            <input type="text" class="form-control" value="{{$contatos->nomeCliente}}" name =nomeContato id="inputNome">
        </div>

        <div class="col-md-4">
            <label for="inputFone" class="form-label">Fone</label>
            <input type="text" class="form-control" value="{{$contatos->foneCliente}}" name =foneContato id="inputFone">
        </div>

        <div class="col-md-8">
            <label for="inputFone" class="form-label">CEP</label>
            <input type="text" class="form-control" value="{{$contatos->cepCliente}}" name =cepCliente id="inputCEP">
        </div>

        <div class="col-md-8">
            <label for="inputFone" class="form-label">CPF</label>
            <input type="text" class="form-control" value="{{$contatos->cpfCliente}}" name =cpfCliente id="inputCPF">
        </div>
    
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Alterar</button>
        </div>
    </form>
</div>

@endsection